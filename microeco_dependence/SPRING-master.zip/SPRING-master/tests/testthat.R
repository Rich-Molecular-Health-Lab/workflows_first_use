library(testthat)
library(SPRING)

test_check("SPRING")
